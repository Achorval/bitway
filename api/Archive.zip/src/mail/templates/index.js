const verifyEmail = require('./verifyEmail');
const resetPassword = require('./resetPassword');

module.exports = {
  verifyEmail: verifyEmail,
  resetPassword: resetPassword
}